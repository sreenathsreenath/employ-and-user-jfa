package com.java.jsf;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;



@ManagedBean
@RequestScoped
public class Login implements Serializable {

	String username;
	String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	Connection connection;
	PreparedStatement pst;

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankInfinite","root", "root");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}
	
   public String validate() throws SQLException {
	  
	   connection = getConnection();
		Statement stmt = getConnection().createStatement();
		String Sql="SELECT count(*) as cnt FROM UserAuth WHERE username=? AND password=?";
		pst = connection.prepareStatement(Sql);
		pst.setString(1, username);
		pst.setString(2, password);
		ResultSet rs = pst.executeQuery();
			rs.next();
			int cnt = rs.getInt("cnt");
			if(cnt==1) {
				return "userShow.xhtml?faces-redirect=true";
			}
			else {
				return "Invalid Credentials...";
			}
			
   
	}
	
	
}
